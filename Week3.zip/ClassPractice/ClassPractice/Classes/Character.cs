﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassPractice.Classes
{
    public abstract class Character
    {   //Delare the class properties
        private string name;
        private int health;
        private List<string> inventory;
        private int attack;
        private int speed;
        private int defense;

        public string Name
        {
            get { return name; } 
            set { name = value; }
        }
        public int Health
        {   //get the health variable and sets it as a property if the class bject
            get { return health; }
            set
            {   //This is a check to make sure the health doesnt fall below 0
                if (value > 0)
                {
                    health = value;
                }
            }
        }
        public List<string> Inventory
        {
            get { return inventory; }
            set { inventory = value; }
        }
        public int Attack
        {
            get { return attack; }
            set { attack = value; }
        }
        public int Speed
        {
            get { return speed; }
            set { speed = value; }
        }
        public int Defense
        {
            get { return defense; }
            set { defense = value; }
        }
        //C# shortcut to setting up properties
        //public string Middle_Name { get; set; }

        //Building constructor - allows quick chracter object creation
        public Character(string new_name, int new_health, List<string> new_inventory, int new_attack, int new_speed, int new_defense)
        {   //chang value to the new one passed into the constructor
            this.name = new_name;
            Health = new_health;//setup the object to still use the data protection created earlier
            Inventory = new_inventory;
            Attack = new_attack;
            Speed = new_speed;
            Defense = new_defense;
        }
        public abstract string Battle(bool isLanded, int damage);
        public virtual string Display()
        {
            return $"Character: {Name} has {Health} health with {Attack} Attack, {Speed} Speed and {Defense} defense";
        }
        //pverloaded display method
        public virtual string Display(int num)
        {
            if (num == 1)
            {
                return $"Character: {Name}";
            }
            else if (num == 2)
            {
                return $"Character: {Name} has {Health} health";
            }
            else if (num == 3)
            {
                return $"Character: {Name} has {Health} health with {Attack} attack";
            }
            else
            {
                return $"Character: {Name} has {Health} health with {Attack} Attack, {Speed} Speed and {Defense} defense";
            }
        }
    }
}
