﻿
using System;
using System.Collections.Generic;
using System.Text;
using ClassPractice.Interfaces;

namespace ClassPractice.Classes
{
    public class Mage : Character, iMagicUser
    {
        public int Mana {  get; set; }
        public List<string> Spells { get; set; }

        public Mage(string new_Name, int health, List<string> inventory, int attack, int speed, int defense, int mana, List<String> spells) :
            base(new_Name, health, inventory, attack, speed, defense)
        {
            Mana = mana;
            Spells = spells;
        }
        public override string Display()
        {
            return $"Character: {Name} has {Health} health with {Attack} Attack, {Speed} Speed, {Defense} defense, and {Mana} mana";
        }
        //Override allows the method to be changed i the subclass
        public override string Display(int num)
        {
            if (num == 1)
            {
                return $"Character: {Name}";
            }
            else if (num == 2)
            {
                return $"Character: {Name} has {Health} health";
            }
            else if (num == 3)
            {
                return $"Character: {Name} has {Health} health with {Mana} mana";
            }
            else
            {
                return $"Character: {Name} has {Health} health with {Attack} Attack, {Speed} Speed and {Defense} defense";
            }
        }

        //The battle method m,ust be put in each class because it is abstract
        public override string Battle(bool hitLanded, int damage)
        {   //M<age will take double damage from attacks
            if (hitLanded)
            {
                Health = Health - damage * 2;
            }
            return $"Health is now {Health}";
        }
        //Interface requires the cast spell method
        public string Cast_Spell(string spell)
        {
            return $"{spell} has been cast";
        }
    }
}

