﻿using System;
using System.Collections.Generic;
using System.Text;
using ClassPractice.Interfaces;

namespace ClassPractice.Classes
{
    public class Barbarian : Character, iFighter
    {
        public int Rage { get; set; }

        public int Crit_Hit { get; set; }


        public Barbarian(string new_Name, int health, List<string> inventory, int attack, int speed, int defense, int rage) :
            base(new_Name, health, inventory, attack, speed, defense)
        {
            Rage = rage;

        }

        public override string Display()
        {
            return $"Character: {Name} has {Health} health with {Attack} Attack, {Speed} Speed, {Defense} defense, and {Rage} rage";
        }
        //Override allows the method to be changed i the subclass
        public override string Display(int num)
        {
            if (num == 1)
            {
                return $"Character: {Name}";
            }
            else if (num == 2)
            {
                return $"Character: {Name} has {Health} health";
            }
            else if (num == 3)
            {
                return $"Character: {Name} has {Health} health with {Rage} rage";
            }
            else
            {
                return $"Character: {Name} has {Health} health with {Attack} Attack, {Speed} Speed and {Defense} defense";
            }
        }


        public override string Battle(bool hitLanded, int damage)
        {   //The barabrain will take half damage from attacks
            if (hitLanded)
            {
                Health = Health - damage % 2;
            }
            return $"Health is now {Health}";
        }
    }
}
        
    

