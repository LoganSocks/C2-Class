using ClassPractice.Classes;
namespace ClassPractice
{
    public partial class CharacterViewForm : Form
    {
        public CharacterViewForm()
        {
            InitializeComponent();
        }
        //create list to hold different characters
        private List<Character> Exisiting_Characters = new List<Character>();
        private void CreateButton_Click(object sender, EventArgs e)
        {   //Code to create an object from the class we created
            /*Character new_Character = new Character("Logan", 100, null, 50, 30, 45);

            //Upodate the label to the new characters name
            CharacterInfoLbl.Text = new_Character.Display();

            string result = new_Character.Battle(true, 5);
            CharacterInfoLbl.Text += result;
            //run the battle again
            result = new_Character.Battle(true, 3);
            CharacterInfoLbl.Text += result;*/

            string Character_Name = Name_Tb.Text;

            int health = (int)Health_Ud.Value;
            //Take inventory sr=tring and convetr to array and then a list
            List<string> inventory = Inventory_Tb.Text.Split(',').ToList();

            int attack = (int)Attack_Ud.Value;
            int speed = (int)Speed_Ud.Value;
            int defense = (int)Defense_Ud.Value;
            int special = (int)Special_Ud.Value;

            Character newCharacter = null;
            if (Type_Cb.Text == "Character")
            {
               // new Character(Character_Name, health, inventory, attack, speed, defense);
            }
            else if (Type_Cb.Text == "Mage")
            {
                newCharacter = new Mage(Character_Name, health, inventory, attack, speed, defense, special, inventory);
            }
           
            else if (Type_Cb.Text == "Barbarian")
            {
                newCharacter = new Barbarian(Character_Name, health, inventory, attack, speed, defense, special);
            }

            Barbarian newBarbarian = new Barbarian(Character_Name, health, inventory, attack, speed, defense, special);
            Mage newMage = new Mage(Character_Name, health, inventory, attack, speed, defense, special, inventory);
            //new Character(Character_Name, health, inventory, attack, speed, defense);
            //Add new characters to the list created
            Exisiting_Characters.Add(newCharacter);
            //reload the updated listbox
            Load_Character_List();

        }
        //Method to get characters into the listbox
        private void Load_Character_List()
        {
            //clear the listbox
            Characters_Lb.Items.Clear();
            //loop through characters and add them to list box
            foreach (Character character in Exisiting_Characters)
            {   //add it to listbox
                Characters_Lb.Items.Add(character.Display());
            }
        }
        private void Characters_Lb_SelectedIndexChanged(object sender, EventArgs e)
        {
            //clear current inventory listbox
            Inventory_Lb.Items.Clear();
            //get the selected character -- Index starts at 0
            Character Selected_Character = Exisiting_Characters[Characters_Lb.SelectedIndex];

            if (Selected_Character.Inventory.Count == 0)
            {
                Characters_Lb.Items.Add("Inventory Empty.");
            }
            //if they have inventory display it
            else
            {
                //loop through the inventory and add each item to the lsiutbox
                foreach (string item in Selected_Character.Inventory)
                {   //display the item and tirm it
                    Inventory_Lb.Items.Add(item.Trim());
                }
            }
        }
        //mAGE, pALADIN, bARBARAN< MONK
        private void Type_Cb_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Type_Cb.Text == "Character")
            {
                Special_Lbl.Text = "";
                Special_Ud.Visible = false;
            }
            else if (Type_Cb.Text == "Mage")
            {
                Special_Lbl.Text = "Mana";
                Special_Ud.Visible = true;
            }
            
            else if (Type_Cb.Text == "Barbarian")
            {
                Special_Lbl.Text = "Rage";
                Special_Ud.Visible = true;
            }
           
        }
    }
}
