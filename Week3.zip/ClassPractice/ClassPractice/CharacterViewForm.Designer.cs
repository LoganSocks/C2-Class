﻿namespace ClassPractice
{
    partial class CharacterViewForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            CreateButton = new Button();
            CharacterInfoLbl = new Label();
            Name_Lbl = new Label();
            Health_Lbl = new Label();
            Inventory_Lbl = new Label();
            Attack_Lbl = new Label();
            Speed_Lbl = new Label();
            Defense_Lbl = new Label();
            Name_Tb = new TextBox();
            Health_Ud = new NumericUpDown();
            Attack_Ud = new NumericUpDown();
            Speed_Ud = new NumericUpDown();
            Defense_Ud = new NumericUpDown();
            Inventory_Tb = new TextBox();
            Characters_Lbl = new Label();
            Characters_Lb = new ListBox();
            Characters_Inventory_Lbl = new Label();
            Inventory_Lb = new ListBox();
            Special_Lbl = new Label();
            Special_Ud = new NumericUpDown();
            Type_Lbl = new Label();
            Type_Cb = new ComboBox();
            ((System.ComponentModel.ISupportInitialize)Health_Ud).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Attack_Ud).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Speed_Ud).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Defense_Ud).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Special_Ud).BeginInit();
            SuspendLayout();
            // 
            // CreateButton
            // 
            CreateButton.Location = new Point(352, 415);
            CreateButton.Name = "CreateButton";
            CreateButton.Size = new Size(75, 23);
            CreateButton.TabIndex = 0;
            CreateButton.Text = "Create";
            CreateButton.UseVisualStyleBackColor = true;
            CreateButton.Click += CreateButton_Click;
            // 
            // CharacterInfoLbl
            // 
            CharacterInfoLbl.AutoSize = true;
            CharacterInfoLbl.Location = new Point(276, 9);
            CharacterInfoLbl.Name = "CharacterInfoLbl";
            CharacterInfoLbl.Size = new Size(45, 15);
            CharacterInfoLbl.TabIndex = 1;
            CharacterInfoLbl.Text = "All Info";
            // 
            // Name_Lbl
            // 
            Name_Lbl.AutoSize = true;
            Name_Lbl.Location = new Point(272, 99);
            Name_Lbl.Name = "Name_Lbl";
            Name_Lbl.Size = new Size(39, 15);
            Name_Lbl.TabIndex = 2;
            Name_Lbl.Text = "Name";
            // 
            // Health_Lbl
            // 
            Health_Lbl.AutoSize = true;
            Health_Lbl.Location = new Point(272, 154);
            Health_Lbl.Name = "Health_Lbl";
            Health_Lbl.Size = new Size(42, 15);
            Health_Lbl.TabIndex = 3;
            Health_Lbl.Text = "Health";
            // 
            // Inventory_Lbl
            // 
            Inventory_Lbl.AutoSize = true;
            Inventory_Lbl.Location = new Point(264, 200);
            Inventory_Lbl.Name = "Inventory_Lbl";
            Inventory_Lbl.Size = new Size(57, 15);
            Inventory_Lbl.TabIndex = 4;
            Inventory_Lbl.Text = "Inventory";
            // 
            // Attack_Lbl
            // 
            Attack_Lbl.AutoSize = true;
            Attack_Lbl.Location = new Point(273, 241);
            Attack_Lbl.Name = "Attack_Lbl";
            Attack_Lbl.Size = new Size(41, 15);
            Attack_Lbl.TabIndex = 5;
            Attack_Lbl.Text = "Attack";
            // 
            // Speed_Lbl
            // 
            Speed_Lbl.AutoSize = true;
            Speed_Lbl.Location = new Point(279, 286);
            Speed_Lbl.Name = "Speed_Lbl";
            Speed_Lbl.Size = new Size(39, 15);
            Speed_Lbl.TabIndex = 6;
            Speed_Lbl.Text = "Speed";
            // 
            // Defense_Lbl
            // 
            Defense_Lbl.AutoSize = true;
            Defense_Lbl.Location = new Point(272, 330);
            Defense_Lbl.Name = "Defense_Lbl";
            Defense_Lbl.Size = new Size(49, 15);
            Defense_Lbl.TabIndex = 7;
            Defense_Lbl.Text = "Defense";
            // 
            // Name_Tb
            // 
            Name_Tb.Location = new Point(326, 99);
            Name_Tb.Name = "Name_Tb";
            Name_Tb.Size = new Size(100, 23);
            Name_Tb.TabIndex = 8;
            // 
            // Health_Ud
            // 
            Health_Ud.Location = new Point(327, 152);
            Health_Ud.Name = "Health_Ud";
            Health_Ud.Size = new Size(120, 23);
            Health_Ud.TabIndex = 9;
            // 
            // Attack_Ud
            // 
            Attack_Ud.Location = new Point(326, 241);
            Attack_Ud.Name = "Attack_Ud";
            Attack_Ud.Size = new Size(120, 23);
            Attack_Ud.TabIndex = 10;
            // 
            // Speed_Ud
            // 
            Speed_Ud.Location = new Point(326, 286);
            Speed_Ud.Name = "Speed_Ud";
            Speed_Ud.Size = new Size(120, 23);
            Speed_Ud.TabIndex = 11;
            // 
            // Defense_Ud
            // 
            Defense_Ud.Location = new Point(327, 328);
            Defense_Ud.Name = "Defense_Ud";
            Defense_Ud.Size = new Size(120, 23);
            Defense_Ud.TabIndex = 12;
            // 
            // Inventory_Tb
            // 
            Inventory_Tb.Location = new Point(326, 200);
            Inventory_Tb.Name = "Inventory_Tb";
            Inventory_Tb.Size = new Size(100, 23);
            Inventory_Tb.TabIndex = 13;
            // 
            // Characters_Lbl
            // 
            Characters_Lbl.AutoSize = true;
            Characters_Lbl.Location = new Point(485, 107);
            Characters_Lbl.Name = "Characters_Lbl";
            Characters_Lbl.Size = new Size(63, 15);
            Characters_Lbl.TabIndex = 14;
            Characters_Lbl.Text = "Characters";
            // 
            // Characters_Lb
            // 
            Characters_Lb.FormattingEnabled = true;
            Characters_Lb.Location = new Point(485, 125);
            Characters_Lb.Name = "Characters_Lb";
            Characters_Lb.Size = new Size(533, 139);
            Characters_Lb.TabIndex = 15;
            Characters_Lb.SelectedIndexChanged += Characters_Lb_SelectedIndexChanged;
            // 
            // Characters_Inventory_Lbl
            // 
            Characters_Inventory_Lbl.AutoSize = true;
            Characters_Inventory_Lbl.Location = new Point(485, 277);
            Characters_Inventory_Lbl.Name = "Characters_Inventory_Lbl";
            Characters_Inventory_Lbl.Size = new Size(119, 15);
            Characters_Inventory_Lbl.TabIndex = 16;
            Characters_Inventory_Lbl.Text = "Character's Inventory";
            // 
            // Inventory_Lb
            // 
            Inventory_Lb.FormattingEnabled = true;
            Inventory_Lb.Location = new Point(485, 295);
            Inventory_Lb.Name = "Inventory_Lb";
            Inventory_Lb.Size = new Size(167, 94);
            Inventory_Lb.TabIndex = 17;
            // 
            // Special_Lbl
            // 
            Special_Lbl.AutoSize = true;
            Special_Lbl.Location = new Point(276, 375);
            Special_Lbl.Name = "Special_Lbl";
            Special_Lbl.Size = new Size(0, 15);
            Special_Lbl.TabIndex = 18;
            // 
            // Special_Ud
            // 
            Special_Ud.Location = new Point(326, 375);
            Special_Ud.Name = "Special_Ud";
            Special_Ud.Size = new Size(120, 23);
            Special_Ud.TabIndex = 19;
            Special_Ud.Visible = false;
            // 
            // Type_Lbl
            // 
            Type_Lbl.AutoSize = true;
            Type_Lbl.Location = new Point(279, 51);
            Type_Lbl.Name = "Type_Lbl";
            Type_Lbl.Size = new Size(32, 15);
            Type_Lbl.TabIndex = 20;
            Type_Lbl.Text = "Type";
            // 
            // Type_Cb
            // 
            Type_Cb.FormattingEnabled = true;
            Type_Cb.Items.AddRange(new object[] { "Character", "Mage", "Paladin", "Barbarian", "Monk" });
            Type_Cb.Location = new Point(326, 51);
            Type_Cb.Name = "Type_Cb";
            Type_Cb.Size = new Size(121, 23);
            Type_Cb.TabIndex = 21;
            Type_Cb.SelectedIndexChanged += Type_Cb_SelectedIndexChanged;
            // 
            // CharacterViewForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1041, 450);
            Controls.Add(Type_Cb);
            Controls.Add(Type_Lbl);
            Controls.Add(Special_Ud);
            Controls.Add(Special_Lbl);
            Controls.Add(Inventory_Lb);
            Controls.Add(Characters_Inventory_Lbl);
            Controls.Add(Characters_Lb);
            Controls.Add(Characters_Lbl);
            Controls.Add(Inventory_Tb);
            Controls.Add(Defense_Ud);
            Controls.Add(Speed_Ud);
            Controls.Add(Attack_Ud);
            Controls.Add(Health_Ud);
            Controls.Add(Name_Tb);
            Controls.Add(Defense_Lbl);
            Controls.Add(Speed_Lbl);
            Controls.Add(Attack_Lbl);
            Controls.Add(Inventory_Lbl);
            Controls.Add(Health_Lbl);
            Controls.Add(Name_Lbl);
            Controls.Add(CharacterInfoLbl);
            Controls.Add(CreateButton);
            Name = "CharacterViewForm";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)Health_Ud).EndInit();
            ((System.ComponentModel.ISupportInitialize)Attack_Ud).EndInit();
            ((System.ComponentModel.ISupportInitialize)Speed_Ud).EndInit();
            ((System.ComponentModel.ISupportInitialize)Defense_Ud).EndInit();
            ((System.ComponentModel.ISupportInitialize)Special_Ud).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button CreateButton;
        private Label CharacterInfoLbl;
        private Label Name_Lbl;
        private Label Health_Lbl;
        private Label Inventory_Lbl;
        private Label Attack_Lbl;
        private Label Speed_Lbl;
        private Label Defense_Lbl;
        private TextBox Name_Tb;
        private NumericUpDown Health_Ud;
        private NumericUpDown Attack_Ud;
        private NumericUpDown Speed_Ud;
        private NumericUpDown Defense_Ud;
        private TextBox Inventory_Tb;
        private Label Characters_Lbl;
        private ListBox Characters_Lb;
        private Label Characters_Inventory_Lbl;
        private ListBox Inventory_Lb;
        private Label Special_Lbl;
        private NumericUpDown Special_Ud;
        private Label Type_Lbl;
        private ComboBox Type_Cb;
    }
}
