﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassPractice.Interfaces
{
    public interface iFighter
    {   //any fighter must have the rage attriute
        int Rage { get; set; }
        //Same for crtitical hit
        int Crit_Hit { get; set; }
    }
}
