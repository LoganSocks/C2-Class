﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ClassPractice.Interfaces
{
    public interface iMagicUser
    {   //Any class that uses this interface must have the mana property
        int Mana {  get; set; }
        //Samething if they use the interface must have spells
        string Cast_Spell(string spell);
    }
}
